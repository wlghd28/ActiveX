//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by mfcdemo.rc
//
#define IDD_HOTSPOTPARAM                101
#define IDD_MFCDEMO_DIALOG              102
#define IDD_VIEWPORTCONTROLDEMO         103
#define IDD_CONTOURCROSSSECTION         104
#define IDD_REALTIMEMULTICHART          105
#define IDD_REALTIMEZOOMSCROLL          106
#define IDD_XYZOOMSCROLL                108
#define IDD_CONTOURZOOMSCROLL           109
#define IDD_MEGAZOOMSCROLL              110
#define IDD_MEGAREALTIMEZOOMSCROLL      111
#define IDD_ZOOMSCROLLTRACK2            112
#define IDD_ZOOMSCROLLTRACK             113
#define IDD_SIMPLEZOOMSCROLL            114
#define IDD_FINANCEDEMO                 115
#define IDD_TRACKCURSOR_DEMO            116
#define IDD_THREEDCHARTROTATION         117
#define IDD_REALTIMEDEMO                118
#define IDD_REALTIMETRACK               119
#define IDD_ZOOMSCROLLPDF               120
#define IDR_MAINFRAME                   128
#define IDI_RunPB                       130
#define IDI_PointerPB                   132
#define IDI_SavePB                      133
#define IDI_ZoomInPB                    134
#define IDI_ZoomOutPB                   135
#define IDI_ZoomOut                     136
#define IDI_ZoomIn                      137
#define IDI_Save                        138
#define IDI_Scroll                      139
#define IDI_FreezePB                    140
#define IDC_ChartViewer                 1000
#define IDC_CHARTVIEWER0                1001
#define IDC_CHARTVIEWER1                1002
#define IDC_CHARTVIEWER2                1003
#define IDC_CHARTVIEWER3                1004
#define IDC_CHARTVIEWER4                1005
#define IDC_CHARTVIEWER5                1006
#define IDC_CHARTVIEWER6                1007
#define IDC_CHARTVIEWER7                1008
#define IDC_HScrollBar                  1009
#define IDC_TIMERANGE                   1010
#define IDC_PARAMLIST                   1011
#define IDC_VOLUME                      1012
#define IDC_LOGSCALE                    1013
#define IDC_CHECK1                      1014
#define IDC_UpdatePeriod                1015
#define IDC_PABABOLICSAR                1016
#define IDC_PointerPB                   1017
#define IDC_ZoomInPB                    1018
#define IDC_ZoomOutPB                   1019
#define IDC_BAND                        1020
#define IDC_CHART_TREE                  1021
#define IDC_AVGTYPE1                    1022
#define IDC_FreezePB                    1023
#define IDC_AlphaValue                  1024
#define IDC_AVGTYPE2                    1025
#define IDC_BetaValue                   1026
#define IDC_MOVAVG1                     1027
#define IDC_GammaValue                  1028
#define IDC_MOVAVG2                     1029
#define IDC_INDICATOR1                  1030
#define IDC_RunPB                       1031
#define IDC_INDICATOR2                  1032
#define IDC_ZoomBar                     1033
#define IDC_CrossSectionViewerX         1034
#define IDC_CrossSectionViewerY         1035
#define IDC_TICKERSYMBOL                1036
#define IDC_COMPAREWITH                 1037
#define IDC_STARTDATE                   1038
#define IDC_ENDDATE                     1039
#define IDC_PlotChartPB                 1040
#define IDC_SavePB                      1041
#define IDC_ALPHA_CB                    1042
#define IDC_BETA_CB                     1043
#define IDC_GAMMA_CB                    1044
#define IDC_ViewPortControl             1045
#define IDC_PERCENTAGESCALE             1046
#define IDC_CHARTTYPE                   1047
#define IDC_SavePdfPB                   1048

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        243
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1049
#define _APS_NEXT_SYMED_VALUE           141
#endif
#endif
